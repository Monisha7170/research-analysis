// static/js/dashboard.js

document.addEventListener("DOMContentLoaded", async function () {

  // --------------------------
  // Daily Uploads & Entities
  // --------------------------
  const metricsResp = await fetch("/api/metrics");
  const metrics = await metricsResp.json();

  // Line chart for daily uploads
  const ctx1 = document.getElementById("uploadsChart").getContext("2d");
  new Chart(ctx1, {
    type: "line",
    data: {
      labels: metrics.daily.map(item => item.day),
      datasets: [{
        label: "Documents Uploaded",
        data: metrics.daily.map(item => item.count),
        borderColor: "#007bff",
        fill: false,
        tension: 0.3
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: true } },
      scales: { y: { beginAtZero: true } }
    }
  });

  // Bar chart for entity counts
  const ctx2 = document.getElementById("entitiesChart").getContext("2d");
  const sortedEntities = Object.entries(metrics.entities || {}).sort((a,b) => b[1]-a[1]);
  new Chart(ctx2, {
    type: "bar",
    data: {
      labels: sortedEntities.map(e => e[0]),
      datasets: [{
        label: "Entity Count",
        data: sortedEntities.map(e => e[1]),
        backgroundColor: "#28a745"
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true } }
    }
  });

  // --------------------------
  // Weekly Upload Trends
  // --------------------------
  const weeklyResp = await fetch("/api/weekly_uploads");
  const weekly = await weeklyResp.json();

  const ctx3 = document.getElementById("weeklyChart").getContext("2d");
  new Chart(ctx3, {
    type: "bar",
    data: {
      labels: weekly.map(w => w.week),
      datasets: [{
        label: "Weekly Uploads",
        data: weekly.map(w => w.count),
        backgroundColor: "rgba(255, 99, 132, 0.3)",
        borderColor: "rgb(255, 99, 132)",
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: true } },
      scales: { y: { beginAtZero: true } }
    }
  });

  // --------------------------
  // Most Common Keywords
  // --------------------------
  const keywordsResp = await fetch("/api/keywords");
  const keywords = await keywordsResp.json();
  const topKeywords = keywords.slice(0, 10); // limit top 10

  const ctx4 = document.getElementById("keywordChart").getContext("2d");
  new Chart(ctx4, {
    type: "bar",
    data: {
      labels: topKeywords.map(k => k.word),
      datasets: [{
        label: "Keyword Frequency",
        data: topKeywords.map(k => k.count),
        backgroundColor: "rgba(54, 162, 235, 0.3)",
        borderColor: "rgb(54, 162, 235)",
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: true } },
      scales: { y: { beginAtZero: true } }
    }
  });

});
